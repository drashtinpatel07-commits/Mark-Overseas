
function greet() { alert('Hello from Mark Overseas!'); }
